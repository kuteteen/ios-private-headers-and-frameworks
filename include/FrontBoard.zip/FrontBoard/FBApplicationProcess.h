@interface FBApplicationProcess : NSObject

@property (nonatomic, retain) NSString *bundleIdentifier;

@end
